package com.example.convertcurrency

data class currency_JSON(
    val date: String,
    val eur: Eur
)