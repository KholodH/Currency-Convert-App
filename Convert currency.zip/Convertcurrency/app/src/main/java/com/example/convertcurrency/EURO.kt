package com.example.convertcurrency

import com.google.gson.annotations.SerializedName
import java.util.*

class EURO {

    var eur: Currency? = null

    class Currency {

        var sar: String? = null

        var usd: String? = null

        var jpy: String? = null

        var kwd: String? = null





    }
}