package com.example.convertcurrency

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers


interface APIInterface {
    //https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies/eur.json


    @GET("eur.json")
    fun getPrices(): Call<EURO>
    @GET("eur.json")

    fun getAll():Call<currency_JSON>
}