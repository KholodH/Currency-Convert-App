package com.example.convertcurrency

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    private lateinit var amount:EditText
    private lateinit var showResult:TextView
    private lateinit var SARBottun: Button
    private lateinit var USDBottun: Button
    private lateinit var JPNBottun: Button
    private lateinit var KWDBottun: Button
    private var result=0.0



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

         amount = findViewById(R.id.addNumber)
        showResult = findViewById(R.id.result)
        SARBottun = findViewById(R.id.bsar)
        USDBottun = findViewById(R.id.busd)
        JPNBottun = findViewById(R.id.bjpn)
        KWDBottun = findViewById(R.id.bkwd)


        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)
        apiInterface?.getPrices()?.enqueue(object: Callback<EURO>{
            override fun onResponse(call: Call<EURO>, response: Response<EURO>) {
                try{

                    // once we get our data, we can update the prices Array List and use it to update the Recycler View
                    SARBottun.setOnClickListener {
                        val num=amount.text.toString()!!
                        if(num.isNotEmpty()) {
                         result=(response.body()!!.eur!!.sar!!.toDouble())*num.toDouble()
                            showResult.setText(result.toString())

                        } }

                    USDBottun.setOnClickListener {
                        val num=amount.text.toString()!!
                        result=(response.body()!!.eur!!.usd!!.toDouble())*(num.toDouble())
                            showResult.setText(result.toString())

                        }
                    JPNBottun.setOnClickListener {
                        val num=amount.text.toString()!!
                        result=(response.body()!!.eur!!.jpy!!.toDouble())*(num.toDouble())
                        showResult.setText(result.toString())

                    }

                    KWDBottun.setOnClickListener {
                        val num=amount.text.toString()!!
                        result=(response.body()!!.eur!!.kwd!!.toDouble())*(num.toDouble())
                        showResult.setText(result.toString())

                    }

                }catch(e: Exception){
                    Log.d("MAIN", "ISSUE: $e")
                }
            }

            override fun onFailure(call: Call<EURO>, t: Throwable) {
                Log.d("MAIN", "Unable to get data")
            }

        })



    }
}